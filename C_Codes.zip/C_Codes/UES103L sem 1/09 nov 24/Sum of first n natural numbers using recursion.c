#include <stdio.h>

// Recursive function to find the sum of the first n natural numbers
int sum(int n) {
    if (n == 1) {
        return 1; // Base case: sum of first natural number is 1
    } 
	else {
    	return n+sum(n-1); // Recursive step
    }
}

int main() {
    int n;

    // Input the value of n from the user
    printf("Enter the value of n: ");
    scanf("%d", &n);

    // Calculate and display the sum
    printf("Sum of first %d natural numbers is %d\n", n, sum(n));

    return 0;
}

