#include <stdio.h>

// Global variable to count the number of steps
int steps = 0;

// Recursive function to solve Tower of Hanoi
void towerOfHanoi(int n, char from_peg, char to_peg, char aux_peg) {
    if (n == 1) {
        printf("Step %d: Move disk 1 from peg %c to peg %c\n", ++steps, from_peg, to_peg);
        return;
    }
    towerOfHanoi(n - 1, from_peg, aux_peg, to_peg);
    printf("Step %d: Move disk %d from peg %c to peg %c\n", ++steps, n, from_peg, to_peg);
    towerOfHanoi(n - 1, aux_peg, to_peg, from_peg);
}

int main() {
    int n;
    printf("Enter the number of disk you need to stack: ");
    scanf("%d",&n);
    towerOfHanoi(n, 'A', 'C', 'B'); // A, B, and C are names of the pegs
    printf("Total steps: %d\n", steps);
    return 0;
}


