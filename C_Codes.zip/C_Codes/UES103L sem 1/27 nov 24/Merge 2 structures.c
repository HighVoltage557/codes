#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a structure
struct Student {
    char name[30];
    int roll;
    float marks;
};
int i;
void inputStudentDetails(struct Student *students, int count) {
    for (i = 0; i < count; i++) {
        printf("\nEnter details for student %d:\n", i + 1);
        getchar(); // Clear newline left in the buffer
        printf("Enter name: ");
        fgets(students[i].name, sizeof(students[i].name), stdin);
        students[i].name[strcspn(students[i].name, "\n")] = '\0'; // Remove newline
        printf("Enter roll number: ");
        scanf("%d", &students[i].roll);
        printf("Enter marks: ");
        scanf("%f", &students[i].marks);
    }
}

void displayStudentDetails(struct Student *students, int count) {
    for (i = 0; i < count; i++) {
        printf("\nStudent %d:\n", i + 1);
        printf("Name: %s\n", students[i].name);
        printf("Roll Number: %d\n", students[i].roll);
        printf("Marks: %.2f\n", students[i].marks);
    }
}

int main() {
    int n1, n2;

    // Input the number of students in the first array
    printf("Enter the number of students in the first array: ");
    scanf("%d", &n1);

    // Dynamically allocate memory for the first array of students
    struct Student *students1 = (struct Student *)malloc(n1 * sizeof(struct Student));
    if (students1 == NULL) {
        printf("Memory allocation failed for the first array!\n");
        return 1;
    }

    // Input details for the first array
    printf("\nInput details for the first array of students:\n");
    inputStudentDetails(students1, n1);

    // Input the number of students in the second array
    printf("\nEnter the number of students in the second array: ");
    scanf("%d", &n2);

    // Dynamically allocate memory for the second array of students
    struct Student *students2 = (struct Student *)malloc(n2 * sizeof(struct Student));
    if (students2 == NULL) {
        printf("Memory allocation failed for the second array!\n");
        free(students1);
        return 1;
    }

    // Input details for the second array
    printf("\nInput details for the second array of students:\n");
    inputStudentDetails(students2, n2);

    // Reallocate memory for the first array to accommodate the second array
    students1 = (struct Student *)realloc(students1, (n1 + n2) * sizeof(struct Student));
    if (students1 == NULL) {
        printf("Memory reallocation failed!\n");
        free(students2);
        return 1;
    }

    // Copy elements of the second array into the resized first array
    for (i = 0; i < n2; i++) {
        students1[n1 + i] = students2[i];
    }

    // Display the merged array
    printf("\nMerged Array of Students:\n");
    displayStudentDetails(students1, n1 + n2);

    // Free the allocated memory
    free(students1);
    free(students2);

    return 0;
}

