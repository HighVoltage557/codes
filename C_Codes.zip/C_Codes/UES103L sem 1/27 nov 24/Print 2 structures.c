#include <stdio.h>
#include <stdlib.h>

// Define a structure
struct Student {
    char name[50];
    int roll;
    float marks;
};

int main() {
    int n, i;

    // Get the number of students
    printf("Enter the number of students: ");
    scanf("%d", &n);

    // Allocate memory for an array of Students
    struct Student *students = (struct Student *)malloc(n * sizeof(struct Student));

    // Check if memory allocation was successful
    if (students == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    // Input details for each student
    for (i = 0; i < n; i++) {
        printf("\nEnter details for student %d:\n", i + 1);
        getchar(); // Clear newline left by previous scanf
        printf("Enter name: ");
        fgets(students[i].name, sizeof(students[i].name), stdin);
        students[i].name[strcspn(students[i].name, "\n")] = '\0'; // Remove newline character
        printf("Enter roll number: ");
        scanf("%d", &students[i].roll);
        printf("Enter marks: ");
        scanf("%f", &students[i].marks);
    }

    // Display details for each student
    printf("\nStudent Details:\n");
    for (i = 0; i < n; i++) {
        printf("\nStudent %d:\n", i + 1);
        printf("Name: %s\n", students[i].name);
        printf("Roll Number: %d\n", students[i].roll);
        printf("Marks: %.2f\n", students[i].marks);
    }

    // Free the allocated memory
    free(students);

    return 0;
}

