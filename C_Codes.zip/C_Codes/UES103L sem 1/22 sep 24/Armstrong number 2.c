// Armstrong number checker
#include <stdio.h>
#include <math.h> 

int main() {
    int num, remainder, sum = 0, temp;
    printf("Enter a three-digit number: ");
    scanf("%d", &num);
    temp = num;

    // Calculate the sum of cubes of individual digits
    while (num > 0) {
        remainder = num % 10;
        sum += pow(remainder, 3); // Raise each digit to the power of 3
        num /= 10;
    }

    if (temp == sum) {
        printf("%d is an Armstrong number.\n", temp);
    } else {
        printf("%d is not an Armstrong number.\n", temp);
    }

    return 0;
}

