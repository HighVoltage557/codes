#include <stdio.h>

int main() {
    int a;
    int b;
    
    a = 5; // Initial value for a
    b = 10; // Initial value for b
    
    // Print initial values of a and b on the same line
    printf("%d a, %d b\n", a, b); 
    
    // Inform about the swapping process
    printf("Swapping Values...\n"); 

    // Swapping values without a temporary variable
    a = a + b; // Now a holds the sum of a and b
    b = a - b; // b now gets the original value of a
    a = a - b; // a now gets the original value of b

    // Print swapped values of a and b
    printf("%d a, %d b\n", a, b); 
    
    return 0; // Exit the program successfully
}
