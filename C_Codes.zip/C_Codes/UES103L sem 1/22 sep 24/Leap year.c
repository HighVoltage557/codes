//Leap year checker

#include <stdio.h>

int main() {
    int year, remainder;

    printf("Enter the year: ");
    scanf("%d", &year);

    // Calculate the remainder based on leap year rules
    remainder = (year % 4 == 0) && ((year % 400 == 0) || (year % 100 != 0));

    switch (remainder) {
        case 1:
            printf("%d is a leap year.\n", year);
            break;
        case 0:
            printf("%d is not a leap year.\n", year);
            break;
        default:
            printf("Invalid input.\n");
            break;
    }

    return 0;
}

