// Asterisk pattern
#include <stdio.h>

int main() {
    int j;
    for (j = 1; j <= 5; j++) {
        int i;
        for (i = 5; i >= j; i--) {
            printf("*");
            
        }
        printf("\n"); // Add a newline after each row
    }
    return 0;
}

