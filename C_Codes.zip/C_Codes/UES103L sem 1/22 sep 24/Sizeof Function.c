//sizeof function
#include <stdio.h>
int a;
float c;
e
