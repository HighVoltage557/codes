//Armstrong number
#include <stdio.h>
#include <math.h>

// Calculate the number of digits.
int countDigits(int num) {
    int count = 0;
    while (num > 0) {
        num /= 10;
        count++;
    }
    return count;
}

// Check if a number is an Armstrong number.
int isArmstrong(int num) {
    int originalNum = num;
    int sum = 0;
    int numDigits = countDigits(num);

    while (num > 0) {
        int digit = num % 10;
        sum += pow(digit, numDigits);
        num /= 10;
    }

    return (sum == originalNum);
}

int main() {
    int number;
    printf("Enter a positive integer: ");
    scanf("%d", &number);

    if (isArmstrong(number)) {
        printf("%d is an Armstrong number!\n", number);
    } else {
        printf("%d is not an Armstrong number.\n", number);
    }

    return 0;
}

