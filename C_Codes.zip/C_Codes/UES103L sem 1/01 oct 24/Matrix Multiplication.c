#include <stdio.h>
int i,j,rowsA,rowsB,colsA,colsB;
int A[][3],B[][3],result[][3]
void multiplyMatrices(A[][2],B[][3],result[][3],rowsA,colsA,colsB) {
    for (i = 0; i < rowsA; ++i) {
        for (j = 0; j < colsB; ++j) {
            result[i][j] = 0;
            for (k = 0; k < colsA; ++k) {
                result[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

int main() {
    int A[][2] = {{1, 2}, {3, 4}, {5, 6}};
    int B[][3] = {{2, 3, 4}, {5, 6, 7}};
    int rowsA = 3;
    int colsA = 2;
    int colsB = 3;

    int result[rowsA][colsB];

    multiplyMatrices(A, B, result, rowsA, colsA, colsB);

    printf("Result of matrix multiplication:\n");
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsB; ++j) {
            printf("%d ", result[i][j]);
        }
        printf("\n");
    }

    return 0;
}

