#include <stdio.h>

int main() {
    int A[][2] = {{1, 2}, {3, 4}, {5, 6}}; //Matrix A
    int B[][3] = {{2, 3, 4}, {5, 8, 7}};   // Matrix B
    //Set number of rows and columns according to the matrices
	int rowsA = 3; 
    int colsA = 2;
    int colsB = 3;
	int i,j,k;
	
    int result[rowsA][colsB];

    // Perform matrix multiplication
    for (i = 0; i < rowsA; ++i) {
        for (j = 0; j < colsB; ++j) {
            result[i][j] = 0;
            for (k = 0; k < colsA; ++k) {
                result[i][j] += A[i][k] * B[k][j];
            }
        }
    }

    // Display the result
    printf("Result of matrix multiplication:\n");
    for (i = 0; i < rowsA; ++i) {
        for (j = 0; j < colsB; ++j) {
            printf("%d ", result[i][j]);
        }
        printf("\n");
    }

    return 0;
}

