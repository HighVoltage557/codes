#include <stdio.h>
int i,j;
void addMatrices(int A[][3], int B[][3], int result[][3], int rows, int cols) {
    for (i = 0; i < rows; ++i) {
        for (j = 0; j < cols; ++j) {
            result[i][j] = A[i][j] + B[i][j];
        }
    }
}

int main() {
    int A[][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int B[][3] = {{9, 8, 7}, {6, 5, 4}, {3, 2, 1}};
    int rows = 3;
    int cols = 3;

    int result[rows][cols];

    addMatrices(A, B, result, rows, cols);

    printf("Result of matrix addition:\n");
    for (i = 0; i < rows; ++i) {
        for (j = 0; j < cols; ++j) {
            printf("%d ", result[i][j]);
        }
        printf("\n");
    }

    return 0;
}

