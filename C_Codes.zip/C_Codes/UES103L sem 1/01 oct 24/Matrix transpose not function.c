#include <stdio.h>

int main() {
    int A[][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int rows = 3;
    int cols = 3;
	int i,j;
    int transpose[cols][rows]; // Resultant transposed matrix

    // Compute the transpose
    for (i = 0; i < rows; ++i) {
        for (j = 0; j < cols; ++j) {
            transpose[j][i] = A[i][j];
        }
    }

    // Display the transposed matrix
    printf("Original matrix:\n");
    for (i = 0; i < rows; ++i) {
        for (j = 0; j < cols; ++j) {
            printf("%d ", A[i][j]);
        }
        printf("\n");
    }

    printf("\nTransposed matrix:\n");
    for (i = 0; i < cols; ++i) {
        for (j = 0; j < rows; ++j) {
            printf("%d ", transpose[i][j]);
        }
        printf("\n");
    }

    return 0;
}

