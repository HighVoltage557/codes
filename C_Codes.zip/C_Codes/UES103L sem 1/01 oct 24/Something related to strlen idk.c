#include <stdio.h>
#include <string.h>
int main() {
	int i=0;
	char C[10];
	gets(C);
	while(i<strlen(C)){
		printf("%c",C[i++]);
	}
}

