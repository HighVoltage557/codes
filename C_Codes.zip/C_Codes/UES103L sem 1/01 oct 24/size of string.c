#include <stdio.h>

int main() {
    char inputString[] = {'a', 'b', 'c', '\0'}; // Assuming a maximum length of 100 characters

    // Calculate the size (length) of the string
    int size = 0;
    while (inputString[size] != '\0') {
        size++;
    }

    printf("Size of the entered string: %d\n", size);

    return 0;
}

