#include <stdio.h>
#include <string.h>
int main() {
	char name[25];
	printf("Enter ur name: ");
	gets(name);
	puts(name);
}

