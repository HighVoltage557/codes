#include <stdio.h>
#include <stdlib.h>

// Function to calculate factorial
int factorial(int n) {
    if (n == 0) {
        return 1; // Factorial of 0 is 1
    } else {
        return n * factorial(n - 1);
    }
}

int main() {
    int number;
    int* result; // Pointer to hold the result

    // Input a number from the user
    printf("Enter a number: ");
    scanf("%d", &number);

    // Allocate memory for the result
    result = (int*)malloc(sizeof(int));
    if (result == NULL) {
        printf("Memory allocation failed!\n");
        return 1; // Exit if memory allocation failed
    }

    // Calculate the factorial and store it in the allocated memory
    *result = factorial(number);

    // Display the factorial
    printf("Factorial of %d is %d\n", number, *result);

    // Free the allocated memory
    free(result);

    return 0;
}

