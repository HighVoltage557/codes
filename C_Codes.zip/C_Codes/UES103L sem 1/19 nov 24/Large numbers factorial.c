#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to multiply large numbers
void multiply(int *result, int *size, int n) {
    int carry = 0;
    int i;
    for (i = 0; i < *size; i++) {
        int product = result[i] * n + carry;
        result[i] = product % 10;
        carry = product / 10;
    }

    // Handle carry for larger numbers
    while (carry) {
        result[(*size)++] = carry % 10;
        carry /= 10;
    }
}

// Function to calculate factorial using dynamic memory allocation
void calculateFactorial(int n) {
    // Initial size of the array to store factorial digits
    int capacity = 1000;
    int *result = (int *)malloc(capacity * sizeof(int));
    if (result == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }

    // Initialize result
    result[0] = 1;
    int size = 1;
	int i;
    // Calculate factorial and resize array if needed
    for (i = 2; i <= n; i++) {
        multiply(result, &size, i);

        // Resize array if necessary
        if (size >= capacity) {
            capacity *= 2;
            result = (int *)realloc(result, capacity * sizeof(int));
            if (result == NULL) {
                printf("Memory allocation failed!\n");
                return;
            }
        }
    }

    // Print the factorial
    printf("Factorial of %d is ", n);
    for (i = size - 1; i >= 0; i--) {
        printf("%d", result[i]);
    }
    printf("\n");

    // Free allocated memory
    free(result);
}

int main() {
    int number;

    // Input a number from the user
    printf("Enter a number: ");
    scanf("%d", &number);

    // Calculate and display the factorial
    calculateFactorial(number);

    return 0;
}

