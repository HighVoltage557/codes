#include <stdio.h>

int binarySearch(int arr[], int x, int low, int high) {
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (x == arr[mid])
            return mid; // Returns the search value index
        else if (x > arr[mid])
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1; // Returns -1 if element is not found
}

int main() {
    int array[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30};
    int x;
    printf("Enter element to search: ");
    scanf("%d",&x);
    int result = binarySearch(array, x, 0, sizeof(array) / sizeof(array[0]) - 1);
    if (result != -1){
        printf("Element is present at index %d\n", result);
	}
	else{
        printf("Element not found\n");
    }
	return 0;
}

