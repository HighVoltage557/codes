#include <stdio.h>
int main() {
    int rows, cols, row1, col1, i, j;

    printf("Enter the number of rows: ");
    scanf("%d", &rows);
    
    printf("Enter the number of columns: ");
    scanf("%d", &cols);

    int matrix[rows][cols];

    printf("Enter the matrix elements:\n");
    for (i = 0; i < rows; ++i) {
        for (j = 0; j < cols; ++j) {
            scanf("%d", &matrix[i][j]);
        }
    }

    // Display the entered matrix
    printf("Entered matrix:\n");
    for (i = 0; i < rows; ++i) {
        for (j = 0; j < cols; ++j) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
    
    printf("Print a specific element: ");
    scanf("%d %d", &row1, &col1);
    printf("%d",matrix[row1,col1]);

    return 0;
}

