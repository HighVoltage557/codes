#include <stdio.h>
int i,j,n;
int binarySearch(int arr[], int x, int low, int high) {
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (x == arr[mid])
            return mid; // Returns the search value index
        else if (x > arr[mid])
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1; // Returns -1 if element is not found
}

void bubbleSort(int arr[], int n) {
    for (i = 0; i < n - 1; ++i) {
        for (j = 0; j < n - i - 1; ++j) {
            if (arr[j] > arr[j + 1]) {
                // Swap arr[j] and arr[j + 1]
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}


int main() {
	int k,l,array[l],x;
	printf("Enter number of elements required in array: ");
	scanf("%d",&l);
	printf("Enter elements of the array: ");
	for (k=0;k<l;i++){
		scanf("%d",&array[i]);
	}
	
	int n = sizeof(array) / sizeof(array[0]);
    printf("Enter element to search: ");
    scanf("%d",&x);
    int result = binarySearch(array, x, 0, sizeof(array) / sizeof(array[0]) - 1);
    if (result != -1){
        printf("Element is present at index %d\n", result);
	}
	else{
        printf("Element not found\n");
    }
	return 0;
}

