#include <stdio.h>
void sum(float num1, float num2){
	printf("Enter the numbers");
	scanf("%f %f",&num1,&num2);
	printf("Sum of %f and %f = %f",num1,num2,num1+num2);
 
}

int main(){
	float a=5,b=7;
	sum(a,b);	
	return 0;
}
