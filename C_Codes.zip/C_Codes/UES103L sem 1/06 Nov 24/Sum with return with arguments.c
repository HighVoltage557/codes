#include <stdio.h>
float sum(float num1, float num2){
	float sum;
	sum=num1+num2;
	return sum;
}

int main(){
	float a,b;
	printf("Enter the numbers");
	scanf("%f %f",&a,&b);
	printf("Sum of %f and %f = %f ",a,b,sum(a,b));	
	return 0;
}
