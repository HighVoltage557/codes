#include <stdio.h>
int main(){
	int i,sum=0,n=0;
	
	printf("Enter size of array: %d",&n);
	scanf("%d",&n);
	int a[n];
	
	printf("Enter values: ");
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
		sum+=a[i];
	}
	
	printf("Sum= %d",sum);
	printf("Average= %d",sum/n);
}
