// Write a program to read in 5 numbers and compute the average, max, min, standard deviation
#include <stdio.h>
#include <math.h>

int main() {
    int n = 5;
    int i;
    double numbers[n];
    double sum = 0.0, avg, max, min, variance, std_deviation;

    // Read the numbers
    printf("Enter %d numbers:\n", n);
    for (i = 0; i < n; ++i) {
        scanf("%lf", &numbers[i]);
        sum += numbers[i];
    }

    // Calculate average
    avg = sum / n;

    // Find maximum and minimum
    max = min = numbers[0];
    for (i = 1; i < n; ++i) {
        if (numbers[i] > max)
            max = numbers[i];
        if (numbers[i] < min)
            min = numbers[i];
    }

    // Calculate variance
    variance = 0.0;
    for (i = 0; i < n; ++i) {
        variance += pow(numbers[i] - avg, 2);
    }
    variance /= n;

    // Calculate standard deviation
    std_deviation = sqrt(variance);

    // Print results
    printf("Average: %.2lf\n", avg);
    printf("Maximum: %.2lf\n", max);
    printf("Minimum: %.2lf\n", min);
    printf("Standard Deviation: %.2lf\n", std_deviation);

    return 0;
}

