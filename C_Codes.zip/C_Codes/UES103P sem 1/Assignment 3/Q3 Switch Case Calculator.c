// To implement calculator (+,-/,*,% ) using switch statement
#include <stdio.h>
int main() {
    float num1, num2, result;
    char op;

    printf("Enter an arithmetic operator (1-5) : (+, -, *, /, %%): ");
    scanf("%c", &op);
    
    printf("Enter two numbers: ");
    scanf("%f %f", &num1, &num2);

    switch (op) {
        case '1':
            result = num1 + num2;
            break;
        case '2':
            result = num1 - num2;
            break;
        case '3':
            result = num1 * num2;
            break;
        case '4':
            if (num2 == 0) {
                printf("Error: Division by zero is not allowed.\n");
                return 1;
            }
            result = num1 / num2;
            break;
        case '5':
            if (num2 == 0) {
                printf("Error: Modulus by zero is not allowed.\n");
                return 1;
            }
            result = (int)num1 % (int)num2;
            break;
        default:
            printf("Error: Invalid operator.\n");
            return 1;
    }

    printf("Result: %.2f\n", result);

    return 0;
}
