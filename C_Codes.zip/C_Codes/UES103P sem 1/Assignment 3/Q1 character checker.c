//For any entered character, check if the entered character is a capital letter, a small letter, a digit or a special symbol
#include <stdio.h>
#include <ctype.h>
int main() {
    char ch;

    printf("Enter a character: ");
    scanf("%c", &ch);

    if (isupper(ch)) {
   	    printf("The entered character is a capital letter.\n");
    } 
	else if (islower(ch)) {
        printf("The entered character is a small letter.\n");
    } 
	else if (isdigit(ch)) {
        printf("The entered character is a digit.\n");
    } 
	else {
        printf("The entered character is a special symbol.\n");
    }

    return 0;
}

