/*
WAP using loop (for, while, do-while):
*Factorial of number
Whether no. is prime or not
X raised to power n
Check if the input integer is an Armstrong number or not?
Range of set of entered nos. by finding smallest and largest
Multiplication table
HCF of two numbers
GCD of two numbers
*Generate Fibonacci series
*/
#include <stdio.h>
#include <stdbool.h>
#include <math.h>

int main() {
    int choice,i;
    do {
        printf("\nMenu:\n");
        printf("1. Factorial of a number\n");
        printf("2. Check if a number is prime\n");
        printf("3. Calculate X raised to power n\n");
        printf("4. Check for Armstrong number\n");
        printf("5. Find the smallest and largest numbers\n");
        printf("6. Generate Fibonacci series\n");
        printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: {
                int n, factorial = 1;
                printf("Enter a non-negative integer: ");
                scanf("%d", &n);
                for (i = 1; i <= n; ++i) {
                    factorial *= i;
                }
                printf("Factorial of %d is %d\n", n, factorial);
                break;
            }
            case 2: {
                int num;
                printf("Enter an integer: ");
                scanf("%d", &num);
                bool isPrime = true;
                if (num <= 1) {
                    isPrime = false;
                } else {
                    for (i = 2; i * i <= num; ++i) {
                        if (num % i == 0) {
                            isPrime = false;
                            break;
                        }
                    }
                }
                if (isPrime) {
                    printf("%d is a prime number.\n", num);
                } else {
                    printf("%d is not a prime number.\n", num);
                }
                break;
            }
            case 3: {
                double base, result = 1;
                int exponent;
                printf("Enter the base: ");
                scanf("%lf", &base);
                printf("Enter the exponent: ");
                scanf("%d", &exponent);
                for (i = 1; i <= exponent; ++i) {
                    result *= base;
                }
                printf("%.2lf raised to the power %d is %.2lf\n", base, exponent, result);
                break;
            }
            case 4: {
                int num, originalNum, sum = 0, digitCount = 0;
                printf("Enter an integer: ");
                scanf("%d", &num);
                originalNum = num;
                while (num != 0) {
                    ++digitCount;
                    int digit = num % 10;
                    sum += pow(digit, digitCount);
                    num /= 10;
                }
                if (sum == originalNum) {
                    printf("%d is an Armstrong number.\n", originalNum);
                } else {
                    printf("%d is not an Armstrong number.\n", originalNum);
                }
                break;
            }
            case 5: {
                int n, num, smallest, largest;
                printf("Enter the number of elements: ");
                scanf("%d", &n);
                printf("Enter %d integers:\n", n);
                scanf("%d", &num);
                smallest = largest = num;
                for (i = 1; i < n; ++i) {
                    scanf("%d", &num);
                    if (num < smallest) {
                        smallest = num;
                    }
                    if (num > largest) {
                        largest = num;
                    }
                }
                printf("Smallest number: %d\n", smallest);
                printf("Largest number: %d\n", largest);
                break;
            }
            case 6: {
                int count, first = 0, second = 1, next;
                printf("Enter the number of terms in the Fibonacci series: ");
                scanf("%d", &count);
                printf("Fibonacci series:\n");
                for (i = 0; i < count; ++i) {
                    if (i <= 1) {
                        next = i;
                    } else {
                        next = first + second;
                        first = second;
                        second = next;
                    }
                    printf("%d ", next);
                }
                printf("\n");
                break;
            }
            case 7:
                printf("Exiting. Have a great day!\n");
                break;
            default:
                printf("Invalid choice. Please select a valid option.\n");
        }
    } while (choice != 7);

    return 0;
}

