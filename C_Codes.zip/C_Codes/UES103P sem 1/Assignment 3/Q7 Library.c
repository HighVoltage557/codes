/*
A library charges a fine for every book returned late. For the first 5 days the fine is 50
paisa, for 6-10 days fine is one rupee and above 10 days fine is 5 rupees. If you return
the book after 30 days your membership will be canceled. WAP to accept no. of days the
member is late to return the book and display the fine or appropriate message
*/
#include <stdio.h>

int main() {
    int daysLate;
    printf("Enter the number of days the member is late: ");
    scanf("%d", &daysLate);

    if (daysLate <= 0) {
        printf("No fine. Thank you for returning the book on time!\n");
    } else if (daysLate <= 5) {
        printf("Fine: 50 paisa.\n");
    } else if (daysLate <= 10) {
        printf("Fine: 1 rupee.\n");
    } else if (daysLate <= 30) {
        printf("Fine: 5 rupees.\n");
    } else {
        printf("Membership canceled due to excessive delay.\n");
    }
    
    return 0;
}

