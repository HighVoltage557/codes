// Read in 20 integers and count the even numbers
#include <stdio.h>

int main() {
    int num,EvenCount = 0,i; 
    printf("Enter 20 integers:\n");

    for (i = 1; i <= 20; ++i) {
        scanf("%d", &num);
        if (num % 2 == 0) {
            EvenCount++;
        }
    }

    printf("Number of even integers entered: %d\n", EvenCount);

    return 0;
}
