// Write a program to read in numbers until the number -999 is encountered. The sum of all numbers read until this point should be printed out.
#include <stdio.h>
#include <stdio.h>
int main() {
    int num, sum = 0;

    printf("Enter numbers (enter -999 to stop):\n");

    while (1) {
        scanf("%d", &num);
        if (num == -999) {
            break; // Exit the loop when -999 is encountered
        }
        sum += num;
    }

    printf("Sum of all entered numbers: %d\n", sum);

    return 0;
}

