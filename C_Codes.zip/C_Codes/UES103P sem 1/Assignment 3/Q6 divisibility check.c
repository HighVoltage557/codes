// To check whether a number is divisible by 5 and/or 8. Print the appropriate message accordingly
#include <stdio.h>
int main() {
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);

    if (number % 5 == 0 && number % 8 == 0) {
        printf("%d is divisible by both 5 and 8.\n", number);
    } else if (number % 5 == 0) {
        printf("%d is divisible by 5.\n", number);
    } else if (number % 8 == 0) {
        printf("%d is divisible by 8.\n", number);
    } else {
        printf("%d is not divisible by either 5 or 8.\n", number);
    }

    return 0;
}

