//To check whether a number is (a)even or odd (b)negative or positive using (i)if-else statements (ii) Ternary Operators
#include <stdio.h>

int main() {
	// (i) Using if-else statements
    int num;
	printf("Using if-else statements to check whether a number is (a) even or odd (b) negative or positive...");
    printf("Enter an integer: ");
    scanf("%d", &num);

    if (num % 2 == 0) {
        printf("%d is even.\n", num);
    } else {
        printf("%d is odd.\n", num);
    }

    if (num >= 0) {
        printf("%d is positive.\n", num);
    } else {
        printf("%d is negative.\n", num);
    }
   


	// (ii) Using Ternary operator
    int num2;
	printf("Using Ternary operator to check whether a number is (a) even or odd (b) negative or positive...");
    printf("Enter an integer: ");
    scanf("%d", &num2);

    printf("%d is %s.\n", num, (num % 2 == 0) ? "even" : "odd");
    printf("%d is %s.\n", num, (num >= 0) ? "positive" : "negative");

    return 0;
}

