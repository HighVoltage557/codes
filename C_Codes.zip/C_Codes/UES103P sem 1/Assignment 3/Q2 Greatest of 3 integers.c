//To find the greatest of 3 integer using 2 medthods (a) if-else statements (b) Ternary operator
#include <stdio.h>

int main() {
	// (a) Using if-else statements
    int num1, num2, num3;
	printf("Using if-else statements to find the greatest of 3 integers...");
    printf("Enter three integers: ");
    scanf("%d %d %d", &num1, &num2, &num3);

    if (num1 >= num2 && num1 >= num3) {
        printf("%d is the greatest.\n", num1);
    } else if (num2 >= num1 && num2 >= num3) {
        printf("%d is the greatest.\n", num2);
    } else {
        printf("%d is the greatest.\n", num3);
    }


	// (b) Using ternary operator
    int num11, num22, num33, maxx;
	printf("Using ternary operator to find the greatest of 3 integers...");
    printf("Enter three integers: ");
    scanf("%d %d %d", &num11, &num22, &num33);

    maxx = (num11 >= num22) ? ((num11 >= num33) ? num11 : num33) : ((num22 >= num33) ? num22 : num33);
    
    printf("The greatest integer is: %d\n", maxx);

    return 0;
}

