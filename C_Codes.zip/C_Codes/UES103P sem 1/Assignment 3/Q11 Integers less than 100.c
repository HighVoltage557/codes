// Keep reading in integers until one integer larger than 100 is not input. For example: 4 -90, 35, 78, 110 QUIT! (since 110 is bigger than 100)
#include <stdio.h>
int main() {
    int num;

    printf("Enter integers (enter an integer larger than 100 to stop):\n");

    while (1) {
        scanf("%d", &num);
        if (num > 100) {
            printf("QUIT! (since %d is bigger than 100)\n", num);
            break; // Exit the loop
        }
    }

    return 0;
}

