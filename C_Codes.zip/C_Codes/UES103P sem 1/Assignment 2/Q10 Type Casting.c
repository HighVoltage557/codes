#include <stdio.h>
#include <stdlib.h>

int main() {
    char *s = "3.145";
    
    // Convert string to float
    float f = atof(s);
    printf("String to float: %f\n", f);
    
    // Convert string to int
    int i = atoi(s);
    printf("String to int: %d\n", i);
    
    // Convert string to double
    double d = strtod(s, NULL);
    printf("String to double: %lf\n", d);

    // Demonstrating type casting of float to int
    int castedInt = (int)f;
    printf("Float to int using casting: %d\n", castedInt);
    
    // Demonstrating type casting of float to double
    double castedDouble = (double)f;
    printf("Float to double using casting: %lf\n", castedDouble);

    return 0;
}

