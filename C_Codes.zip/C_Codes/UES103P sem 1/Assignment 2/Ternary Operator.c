//Conditional or Ternary Operator
#include <stdio.h>
float a,b,c;
int main(){
	printf("Enter first number: ");	
	scanf("%f",&a);
	printf("Enter second number: ");	
	scanf("%f",&b);
	printf("Enter third number: ");	
	scanf("%f",&c);
    (a>b)?((a>c)?printf("First number is greatest"):printf("Third number is greatest")):((b>c)?printf("Second number is greatest"):printf("Third number is greatest"));
}
