#include <stdio.h>

int main() {
    int num = 10; // Example number

    // Left shift by 2 positions
    int leftShiftResult = num << 2;
    printf("Left shift result: %d\n", leftShiftResult);

    // Right shift by 1 position
    int rightShiftResult = num >> 1;
    printf("Right shift result: %d\n", rightShiftResult);

    // Ask your lab instructor for real-world applications!
    printf("Lab Instructor, could you share some practical applications of bitwise shift operators?\n");

    return 0;
}

