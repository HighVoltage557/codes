#include <stdio.h>

float p,r,t,i,a;

int main() {
    printf("Enter Principal: ");
    scanf("%f", &p);

    printf("Enter rate per time period: ");
    scanf("%f", &r);

    printf("Enter no. of time periods: ");
    scanf("%f", &t);
	
	i=p*(r/100)*t;
	a=i+p;
	printf("Interest = %f",i);
	printf("Amount = %f",a);    

	return 0;
}

