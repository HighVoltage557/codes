#include <stdio.h>
int x;
int main(){
	printf("Enter integer: ");
	scanf("%d",&x);
	printf("Entered Integer %d",x);
}

