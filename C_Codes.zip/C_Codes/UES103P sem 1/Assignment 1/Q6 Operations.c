#include <stdio.h>

float x, y;

int main() {
    printf("Enter first number X: ");
    scanf("%f", &x);

    printf("Enter second number Y: ");
    scanf("%f", &y);

    printf("X + Y = %.2f\n", x + y);
    printf("X - Y = %.2f\n", x - y);
    printf("Y - X = %.2f\n", y - x);
    printf("X / Y = %.2f\n", x / y);
    printf("Y / X = %.2f\n", y / x);
    printf("X * Y = %.2f\n", x * y);

    return 0;
}

