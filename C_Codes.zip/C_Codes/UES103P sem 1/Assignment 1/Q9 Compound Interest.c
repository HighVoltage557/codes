#include <stdio.h>
#include <math.h>
float a,p,r,n,t;

int main() {
    printf("Enter principal: ");
    scanf("%f", &p);

    printf("Enter rate of interest: ");
    scanf("%f", &r);

    printf("Enter number of time to interest apply per time period: ");
    scanf("%f", &n);

    printf("Enter time period: ");
    scanf("%f", &t);
	
	a = p*pow((1+r/(n*100)),n*t);
	
	printf("Final Amount = %f",a);
	printf("Interest Amount = %f%f",a-p);    
    
	return 0;
}

