#include <stdio.h>
#include <math.h>
float x, y;
		
int main() {
    printf("Enter number: ");
    scanf("%f", &x);

    printf("Enter nth root to calculate: ");
    scanf("%f", &y);

	printf("Nth root = %f",pow(x,1/y));
	
    return 0;
}

