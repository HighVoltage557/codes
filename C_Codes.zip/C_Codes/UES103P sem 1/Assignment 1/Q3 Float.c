#include <stdio.h>
float x;
int main(){
	printf("Enter float: ");
	scanf("%f",&x);
	printf("Entered Integer %f",x);
}

