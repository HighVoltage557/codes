#include <stdio.h>

float x;
float pi=3.14;

int main() {
    printf("Enter radius: ");
    scanf("%f", &x);
	printf("Area = %f",pi*x*x);
    return 0;
}

