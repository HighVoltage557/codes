#include <stdio.h>
char x;
int main(){
	printf("Enter character: ");
	scanf("%c",&x);
	printf("Entered Character %c",x);
}

