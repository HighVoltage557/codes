#include <stdio.h>
#include <string.h>

// Define a structure
struct Student {
    char name[30];
    int roll;
    float marks;
};

// Function to display student details using a pointer (arrow operator)
void displayUsingArrowOperator(struct Student *student) {
    printf("\nDisplaying using arrow operator:\n");
    printf("Name: %s\n", student->name);      // Using -> to access structure members
    printf("Roll Number: %d\n", student->roll);
    printf("Marks: %.2f\n", student->marks);
}

// Function to display student details using a structure variable (dot operator)
void displayUsingDotOperator(struct Student student) {
    printf("\nDisplaying using dot operator:\n");
    printf("Name: %s\n", student.name);       // Using . to access structure members
    printf("Roll Number: %d\n", student.roll);
    printf("Marks: %.2f\n", student.marks);
}

int main() {
    // Create a structure variable
    struct Student student1 = {"Alice", 101, 95.5};

    // Call function to display details using the dot operator
    displayUsingDotOperator(student1);

    // Call function to display details using the arrow operator
    displayUsingArrowOperator(&student1); // Passing address of structure

    return 0;
}

