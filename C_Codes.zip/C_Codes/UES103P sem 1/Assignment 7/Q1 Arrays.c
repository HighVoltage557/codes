#include <stdio.h>

int main() {
    char names[3][30];
    int roll[3];
    float marks[3];
    int i;

    // Input details for 3 students
    for (i = 0; i < 3; i++) {
        printf("Enter name of student %d: ", i + 1);
        fgets(names[i], sizeof(names[i]), stdin);
        // Remove trailing newline character if present
        size_t len = strlen(names[i]);
        if (len > 0 && names[i][len - 1] == '\n') {
            names[i][len - 1] = '\0';
        }
        
        printf("Enter roll number of student %d: ", i + 1);
        scanf("%d", &roll[i]);

        printf("Enter marks of student %d: ", i + 1);
        scanf("%f", &marks[i]);
        getchar(); // Clear the newline character from input buffer
    }

    // Output the details of 3 students
    printf("\nDetails of students:\n");
    for (i = 0; i < 3; i++) {
        printf("Student %d\n", i + 1);
        printf("Name: %s\n", names[i]);
        printf("Roll Number: %d\n", roll[i]);
        printf("Marks: %.2f\n", marks[i]);
        printf("\n");
    }

    return 0;
}

