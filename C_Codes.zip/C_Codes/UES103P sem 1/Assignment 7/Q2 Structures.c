#include <stdio.h>
#include <string.h>

// Define a structure to hold student details
struct Student {
    char name[30];
    int roll;
    float marks;
};

int main() {
    struct Student students[3]; // Array of 3 Student structures
    int i;

    // Input details for 3 students
    for (i = 0; i < 3; i++) {
        printf("Enter name of student %d: ", i + 1);
        fgets(students[i].name, sizeof(students[i].name), stdin);
        // Remove trailing newline character if present
        size_t len = strlen(students[i].name);
        if (len > 0 && students[i].name[len - 1] == '\n') {
            students[i].name[len - 1] = '\0';
        }

        printf("Enter roll number of student %d: ", i + 1);
        scanf("%d", &students[i].roll);

        printf("Enter marks of student %d: ", i + 1);
        scanf("%f", &students[i].marks);
        getchar(); // Clear the newline character from input buffer
    }

    // Output the details of 3 students
    printf("\nDetails of students:\n");
    for (i = 0; i < 3; i++) {
        printf("Student %d\n", i + 1);
        printf("Name: %s\n", students[i].name);
        printf("Roll Number: %d\n", students[i].roll);
        printf("Marks: %.2f\n", students[i].marks);
        printf("\n");
    }

    return 0;
}

