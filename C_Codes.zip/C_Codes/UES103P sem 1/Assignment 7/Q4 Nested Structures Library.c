#include <stdio.h>
#include <string.h>

// Define a structure for Author details
struct Author {
    char name[50];
    int age;
};

// Define a structure for Publication details
struct Publication {
    char publisher[50];
    int year;
};

// Define a structure for Book that includes Author and Publication as nested structures
struct Book {
    char title[100];
    struct Author author;         // Nested Author structure
    struct Publication publication; // Nested Publication structure
};

int main() {
    // Create and initialize a book
    struct Book book1;

    // Input details for the book
    printf("Enter book title: ");
    fgets(book1.title, sizeof(book1.title), stdin);
    book1.title[strcspn(book1.title, "\n")] = '\0'; // Remove trailing newline

    printf("Enter author name: ");
    fgets(book1.author.name, sizeof(book1.author.name), stdin);
    book1.author.name[strcspn(book1.author.name, "\n")] = '\0';

    printf("Enter author age: ");
    scanf("%d", &book1.author.age);
    getchar(); // Clear newline from input buffer

    printf("Enter publisher name: ");
    fgets(book1.publication.publisher, sizeof(book1.publication.publisher), stdin);
    book1.publication.publisher[strcspn(book1.publication.publisher, "\n")] = '\0';

    printf("Enter publication year: ");
    scanf("%d", &book1.publication.year);

    // Display the book details
    printf("\nBook Details:\n");
    printf("Title: %s\n", book1.title);
    printf("Author: %s\n", book1.author.name);
    printf("Author Age: %d\n", book1.author.age);
    printf("Publisher: %s\n", book1.publication.publisher);
    printf("Publication Year: %d\n", book1.publication.year);

    return 0;
}

