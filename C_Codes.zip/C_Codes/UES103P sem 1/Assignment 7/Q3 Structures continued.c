#include <stdio.h>
#include <string.h>

// Define a structure
struct Student {
    char name[30];
    int roll;
    float marks;
};

int main() {
    // Initialize a structure directly
    struct Student student1 = {"Alice", 101, 95.5};
    
    // Initialize another structure with default values
    struct Student student2 = {"Bob", 102, 88.75};
    
    // Declare a third structure
    struct Student student3;

    // Copy the entire structure of student1 to student3
    student3 = student1;

    // Display all students after copying the full structure
    printf("After copying full structure:\n");
    printf("Student 3:\n");
    printf("Name: %s, Roll: %d, Marks: %.2f\n", student3.name, student3.roll, student3.marks);

    // Copy only specific fields from student2 to student3
    strcpy(student3.name, student2.name); // Copy name
    student3.marks = student2.marks;      // Copy marks

    // Display student3 after copying specific fields
    printf("\nAfter copying specific variables from student2 to student3:\n");
    printf("Student 3:\n");
    printf("Name: %s, Roll: %d, Marks: %.2f\n", student3.name, student3.roll, student3.marks);

    return 0;
}

