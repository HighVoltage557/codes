#include <stdio.h>

int main() {
    char str[] = "Hello, World!";
    int vowels = 0;
	int i;
    for (i = 0; str[i] != '\0'; i++) {
        char ch = str[i];
        if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' ||
            ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
            vowels++;
        }
    }

    printf("Number of vowels: %d\n", vowels);

    return 0;
}

