/* 
#include <stdio.h>
#include <string.h>

int main() {
    char source[] = "Hello, World!";
    char destination[50];

    // Using strcpy
    strcpy(destination, source);

    printf("Source: %s\n", source);
    printf("Destination: %s\n", destination);

    return 0;
}
*/

#include <stdio.h>

int main() {
    char source[] = "Hello, World!";
    char destination[50];
    int i = 0;

    // Copying manually
    while (source[i] != '\0') {
        destination[i] = source[i];
        i++;
    }
    destination[i] = '\0'; // Null-terminate the destination string

    printf("Source: %s\n", source);
    printf("Destination: %s\n", destination);

    return 0;
}

