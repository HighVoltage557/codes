#include <stdio.h>

// Function to modify and return an array
int* modifyArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        arr[i] *= 2; // Example operation: doubling each element
    }
    return arr;
}

int main() {
    int size = 5;
    int myArray[] = {1, 2, 3, 4, 5};

    printf("Original array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", myArray[i]);
    }
    printf("\n");

    // Call the function and modify the array
    int* modifiedArray = modifyArray(myArray, size);

    printf("Modified array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", modifiedArray[i]);
    }
    printf("\n");

    return 0;
}

