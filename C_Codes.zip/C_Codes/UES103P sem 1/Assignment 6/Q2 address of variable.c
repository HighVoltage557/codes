#include <stdio.h>

int main() {
    int var = 42;
    int *ptr = &var;

    printf("Using %%u: %u\n", ptr);
    printf("Using %%p: %p\n", (void *)ptr);
    printf("Using %%x: %x\n", (unsigned int)ptr);

    return 0;
}

