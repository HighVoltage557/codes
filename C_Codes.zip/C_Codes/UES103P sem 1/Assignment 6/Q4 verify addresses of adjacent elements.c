#include <stdio.h>

int main() {
    // Arrays of different types
    char charArray[] = {'a', 'b', 'c'};
    int intArray[] = {1, 2, 3};
    float floatArray[] = {1.1, 2.2, 3.3};

    printf("Addresses of elements in charArray:\n");
    for (int i = 0; i < 3; i++) {
        printf("&charArray[%d] = %p\n", i, (void*)&charArray[i]);
    }

    printf("\nAddresses of elements in intArray:\n");
    for (int i = 0; i < 3; i++) {
        printf("&intArray[%d] = %p\n", i, (void*)&intArray[i]);
    }

    printf("\nAddresses of elements in floatArray:\n");
    for (int i = 0; i < 3; i++) {
        printf("&floatArray[%d] = %p\n", i, (void*)&floatArray[i]);
    }

    return 0;
}

