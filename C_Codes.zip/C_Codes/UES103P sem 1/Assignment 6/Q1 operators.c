#include <stdio.h>

int main() {
    int i = 10;
    float f = 20.5;
    char c = 'A';

    // Printing the values and addresses
    printf("Value of int variable i is: %d and the address is: %p \n",i,i);
    printf("Value of float variable f is: %f and the address is: %p \n",f,&f);
    printf("Value of char variable c is: %c and the address is: %p \n",c,&c);

    // Using pointers to print values
    int *iptr = &i;
    float *fptr = &f;
    char *cptr = &c;

    printf("Value of int variable i using pointer: %d\n", *iptr);
    printf("Value of float variable f using pointer: %.2f\n", *fptr);
    printf("Value of char variable c using pointer: %c\n", *cptr);

    return 0;
}

