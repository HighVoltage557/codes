#include <stdio.h>
#include <string.h>

int main() {
    char str[] = "UNIVERSITY";
    int len = strlen(str);
	int i,j;
    // Loop to print the pattern
    for (i = 0; i < len; i++) {
        // Print characters up to the i-th character
        for (j = 0; j <= i; j++) {
            printf("%c ", str[j]);
        }
        printf("\n");
    }

    // Loop to print the pattern in reverse
    for (i = len - 2; i >= 0; i--) {
        // Print characters up to the i-th character
        for (j = 0; j <= i; j++) {
            printf("%c ", str[j]);
        }
        printf("\n");
    }

    return 0;
}

