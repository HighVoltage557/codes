#include <stdio.h>

// Function to swap two integers
void swap(int *x, int *y) {
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}

int main() {
    int a = 5, b = 10;

    printf("Before swap: a = %d, b = %d\n", a, b);

    // Call the swap function
    swap(&a, &b);

    printf("After swap: a = %d, b = %d\n", a, b);

    return 0;
}

