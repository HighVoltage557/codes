#include <stdio.h>

// Function to add digits of an integer
int addDigits(int num) {
    int sum = 0;

    while (num != 0) {
        sum += num % 10; // Add the last digit
        num /= 10;       // Remove the last digit
    }

    return sum;
}

int main() {
    int number;

    // Input a number from the user
    printf("Enter an integer: ");
    scanf("%d", &number);

    // Calculate and display the sum of digits
    printf("Sum of digits of %d is %d\n", number, addDigits(number));

    return 0;
}

