#include <stdio.h>

// Recursive function to calculate GCD
int gcd(int a, int b) {
    if (b == 0) {
        return a; // Base case: if b is 0, GCD is a
    } else {
        return gcd(b, a % b); // Recursive step
    }
}

int main() {
    int num1, num2;

    // Input two numbers from the user
    printf("Enter two numbers: ");
    scanf("%d %d", &num1, &num2);

    // Calculate and display the GCD
    printf("GCD of %d and %d is %d\n", num1, num2, gcd(num1, num2));

    return 0;
}

