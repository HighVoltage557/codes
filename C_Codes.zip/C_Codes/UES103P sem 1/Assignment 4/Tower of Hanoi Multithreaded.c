#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

// Global variable to count the number of steps
int steps = 0;
pthread_mutex_t steps_mutex;

// Structure to pass arguments to the thread function
typedef struct {
    int n;
    char from_peg;
    char to_peg;
    char aux_peg;
} ThreadArgs;

// Recursive function to solve Tower of Hanoi using threads
void* towerOfHanoi(void* args) {
    ThreadArgs* ta = (ThreadArgs*)args;
    int n = ta->n;
    char from_peg = ta->from_peg;
    char to_peg = ta->to_peg;
    char aux_peg = ta->aux_peg;

    if (n == 1) {
        pthread_mutex_lock(&steps_mutex);
        printf("Step %d: Move disk 1 from peg %c to peg %c\n", ++steps, from_peg, to_peg);
        pthread_mutex_unlock(&steps_mutex);
        pthread_exit(NULL);
    }

    // Create threads for the recursive calls
    pthread_t thread1, thread2;
    ThreadArgs ta1 = {n - 1, from_peg, aux_peg, to_peg};
    ThreadArgs ta2 = {n - 1, aux_peg, to_peg, from_peg};

    pthread_create(&thread1, NULL, towerOfHanoi, (void*)&ta1);
    pthread_create(&thread2, NULL, towerOfHanoi, (void*)&ta2);

    pthread_join(thread1, NULL);

    pthread_mutex_lock(&steps_mutex);
    printf("Step %d: Move disk %d from peg %c to peg %c\n", ++steps, n, from_peg, to_peg);
    pthread_mutex_unlock(&steps_mutex);

    pthread_join(thread2, NULL);

    pthread_exit(NULL);
}

int main() {
    int n;
    printf("Enter the number of disks you need to stack: ");
    scanf("%d", &n);
    
    pthread_mutex_init(&steps_mutex, NULL);

    ThreadArgs ta = {n, 'A', 'C', 'B'};

    pthread_t main_thread;

    pthread_create(&main_thread, NULL, towerOfHanoi, (void*)&ta);
    pthread_join(main_thread, NULL);
    
    printf("Total steps: %d\n", steps);
    
	pthread_mutex_destroy(&steps_mutex);
    return 0;
}

