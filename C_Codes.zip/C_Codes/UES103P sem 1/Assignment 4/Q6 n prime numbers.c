#include <stdio.h>

// Function to check if a number is prime
int isPrime(int num) {
    if (num <= 1) return 0; // Numbers less than or equal to 1 are not prime
    int i;
	for (i = 2; i <= num / 2; i++) {
        if (num % i == 0) return 0; // If divisible by any number other than 1 and itself, not prime
    }
    return 1; // If not divisible by another number then prime
}

int main() {
    int n, count = 0, num = 2;

    // Input the number of prime numbers to display
    printf("Enter the number of prime numbers to display: ");
    scanf("%d", &n);

    // Display the first n prime numbers
    printf("The first %d prime numbers are: \n", n);
    while (count < n) {
        if (isPrime(num)) {
            printf("%d ", num);
            count++;
        }
        num++;
    }
    printf("\n");

    return 0;
}

