#include <stdio.h>

// Recursive function to calculate factorial
int factorial(long long int n) {
    if (n == 0) {
        return 1; // Base case: factorial of 0 is 1
    } else {
        return n * factorial(n - 1); // Recursive step
    }
}

int main() {
    int number;
	printf("Enter a number to calculate the factorial: ");
	scanf("%d",&number);
	
	printf("Factorial of %d = %lld",number,factorial(number));
    return 0;
}

