#include <stdio.h>

int main() {
    int r1 = 2, c1 = 3;
    int r2 = 3, c2 = 2;

    int a[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int b[3][2] = {{7, 8}, {9, 10}, {11, 12}};

    int addResult[2][3], multResult[2][2], transResult[3][2];

    // Add matrices
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c1; j++) {
            addResult[i][j] = a[i][j] + a[i][j];  // Adding matrix a to itself
        }
    }

    printf("Addition of matrices:\n");
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c1; j++) {
            printf("%d ", addResult[i][j]);
        }
        printf("\n");
    }

    // Multiply matrices
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c2; j++) {
            multResult[i][j] = 0;
            for (int k = 0; k < c1; k++) {
                multResult[i][j] += a[i][k] * b[k][j];
            }
        }
    }

    printf("Multiplication of matrices:\n");
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c2; j++) {
            printf("%d ", multResult[i][j]);
        }
        printf("\n");
    }

    // Transpose matrix
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c1; j++) {
            transResult[j][i] = a[i][j];
        }
    }

    printf("Transpose of matrix:\n");
    for (int i = 0; i < c1; i++) {
        for (int j = 0; j < r1; j++) {
            printf("%d ", transResult[i][j]);
        }
        printf("\n");
    }

    return 0;
}

