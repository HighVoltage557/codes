#include <stdio.h>
int i;

int main() {
    int myIntArray[] = {10, 20, 30, 40, 50};
    int size = sizeof(myIntArray) / sizeof(myIntArray[0]);

    int indexToDelete = 2; // Index of the element to delete

    printf("Original array: ");
    for (i = 0; i < size; i++) {
        printf("%d ", myIntArray[i]);
    }

    // Shift elements to the left to overwrite the deleted element
    for (i = indexToDelete; i < size - 1; i++) {
        myIntArray[i] = myIntArray[i + 1];
    }

    size--; // Decrease the size of the array

    printf("\nArray after deletion: ");
    for (i = 0; i < size; i++) {
        printf("%d ", myIntArray[i]);
    }

    return 0;
}

