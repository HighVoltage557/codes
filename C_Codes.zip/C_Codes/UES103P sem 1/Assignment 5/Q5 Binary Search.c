#include <stdio.h>

int binarySearch(int arr[], int size, int target) {
    int left = 0;
    int right = size - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2; // Calculate middle index

        if (arr[mid] == target)
            return mid; // Element found at index 'mid'

        if (arr[mid] < target)
            left = mid + 1; // Search right half
        else
            right = mid - 1; // Search left half
    }

    return -1; // Element not found
}

int main() {
    int mySortedArray[] = {10, 20, 30, 40, 50};
    int size = sizeof(mySortedArray) / sizeof(mySortedArray[0]);
    int target = 30;

    int result = binarySearch(mySortedArray, size, target);

    if (result != -1)
        printf("Element %d found at index %d.\n", target, result);
    else
        printf("Element %d not found in the array.\n", target);

    return 0;
}

