#include <stdio.h>

int main() {
    float myFloatArray[10] = {1.1, 2.2, 3.3, 4.4, 5.5};
    int size = 5; // Current size of the array
	int i;

    int indexToInsert = 3; // Index where we want to insert
    float newValue = 3.14; // Value to insert

    printf("Original array: ");
    for (i = 0; i < size; i++) {
        printf("%.2f ", myFloatArray[i]);
    }

    // Shift elements to the right to make space for the new element
    for (i = size; i > indexToInsert; i--) {
        myFloatArray[i] = myFloatArray[i - 1];
    }

    // Insert the new element
    myFloatArray[indexToInsert] = newValue;
    size++; // Increase the size of the array

    printf("\nArray after insertion: ");
    for (i = 0; i < size; i++) {
        printf("%.2f ", myFloatArray[i]);
    }

    return 0;
}

