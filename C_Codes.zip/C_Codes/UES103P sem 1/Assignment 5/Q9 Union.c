#include <stdio.h>

int main() {
    int arr1[] = {1, 2, 2, 3, 4, 5};
    int size1 = sizeof(arr1) / sizeof(arr1[0]);
    int arr2[] = {2, 3, 4, 4, 5, 6};
    int size2 = sizeof(arr2) / sizeof(arr2[0]);

    printf("Union of the two arrays: ");

    int i = 0, j = 0;
    while (i < size1 && j < size2) {
        if (arr1[i] < arr2[j])
            printf("%d ", arr1[i++]);
        else if (arr1[i] > arr2[j])
            printf("%d ", arr2[j++]);
        else {
            printf("%d ", arr1[i]);
            i++;
            j++;
        }
    }

    // Remaining elements from arr1 (if any)
    while (i < size1)
        printf("%d ", arr1[i++]);

    // Remaining elements from arr2 (if any)
    while (j < size2)
        printf("%d ", arr2[j++]);

    return 0;
}

