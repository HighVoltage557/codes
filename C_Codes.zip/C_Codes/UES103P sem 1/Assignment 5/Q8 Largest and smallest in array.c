#include <stdio.h>

int main() {
    int myArray[] = {10, 20, 5, 40, 30};
    int size = sizeof(myArray) / sizeof(myArray[0]);

    int largest = myArray[0]; // Initialize with the first element
    int smallest = myArray[0]; // Initialize with the first element

    for (int i = 1; i < size; i++) {
        if (myArray[i] > largest) {
            largest = myArray[i];
        }
        if (myArray[i] < smallest) {
            smallest = myArray[i];
        }
    }

    printf("Largest element: %d\n", largest);
    printf("Smallest element: %d\n", smallest);

    return 0;
}

