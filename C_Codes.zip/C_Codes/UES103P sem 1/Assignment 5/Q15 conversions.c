#include <stdio.h>

// Function to convert decimal to binary
void decimalToBinary(int num) {
    int binaryNum[32];
    int i = 0;
    while (num > 0) {
        binaryNum[i] = num % 2;
        num = num / 2;
        i++;
    }

    printf("Binary: ");
    for (int j = i - 1; j >= 0; j--) {
        printf("%d", binaryNum[j]);
    }
    printf("\n");
}

// Function to convert decimal to octal
void decimalToOctal(int num) {
    int octalNum[32];
    int i = 0;
    while (num > 0) {
        octalNum[i] = num % 8;
        num = num / 8;
        i++;
    }

    printf("Octal: ");
    for (int j = i - 1; j >= 0; j--) {
        printf("%d", octalNum[j]);
    }
    printf("\n");
}

// Function to convert decimal to hexadecimal
void decimalToHexadecimal(int num) {
    char hexNum[32];
    int i = 0;
    while (num > 0) {
        int temp = num % 16;
        if (temp < 10) {
            hexNum[i] = temp + 48;
        } else {
            hexNum[i] = temp + 55;
        }
        num = num / 16;
        i++;
    }

    printf("Hexadecimal: ");
    for (int j = i - 1; j >= 0; j--) {
        printf("%c", hexNum[j]);
    }
    printf("\n");
}

int main() {
    int num;

    // Example decimal number
    printf("Enter a decimal number: ");
    scanf("%d", &num);

    decimalToBinary(num);
    decimalToOctal(num);
    decimalToHexadecimal(num);

    return 0;
}

