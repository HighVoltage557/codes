#include <stdio.h>

int main() {
    int myIntArray[] = {1, 2, 3, 4, 5};
    int size = sizeof(myIntArray) / sizeof(myIntArray[0]);
	int i,start,end;
	
    printf("Original array: ");
    for (i = 0; i < size; i++) {
        printf("%d ", myIntArray[i]);
    }

    // Reverse the array in-place
    for (start = 0, end = size - 1; start < end; start++, end--) {
        int temp = myIntArray[start];
        myIntArray[start] = myIntArray[end];
        myIntArray[end] = temp;
    }

    printf("\nReversed array: ");
    for (i = 0; i < size; i++) {
        printf("%d ", myIntArray[i]);
    }

    return 0;
}

