#include <stdio.h>
#include <stdlib.h>

int main() {
    int n = 10;
    int arr[] = {1, 2, 2, 3, 4, 5, 5, 5, 6, 7};
    int temp;

    // Calculate mean
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    float mean = (float)sum / n;
    printf("Mean: %.2f\n", mean);

    // Sort array for median and mode calculation using Bubble Sort
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    // Calculate median
    float median;
    if (n % 2 == 0) {
        median = (arr[n / 2 - 1] + arr[n / 2]) / 2.0;
    } else {
        median = arr[n / 2];
    }
    printf("Median: %.2f\n", median);

    // Calculate mode
    int mode = arr[0];
    int maxCount = 1, count = 1;

    for (int i = 1; i < n; i++) {
        if (arr[i] == arr[i - 1]) {
            count++;
        } else {
            if (count > maxCount) {
                maxCount = count;
                mode = arr[i - 1];
            }
            count = 1;
        }
    }
    // Final check if the last element is the mode
    if (count > maxCount) {
        mode = arr[n - 1];
    }

    printf("Mode: %d\n", mode);

    return 0;
}

