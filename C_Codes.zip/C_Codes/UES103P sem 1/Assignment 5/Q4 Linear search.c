#include <stdio.h>

int main() {
    int myIntArray[] = {10, 20, 30, 40, 50};
    int size = sizeof(myIntArray) / sizeof(myIntArray[0]);
    int target = 30; // Element to search for

    int foundIndex = -1; // Initialize with -1 (not found)

    for (int i = 0; i < size; i++) {
        if (myIntArray[i] == target) {
            foundIndex = i;
            break; // Stop searching once found
        }
    }

    if (foundIndex != -1) {
        printf("Element %d found at index %d.\n", target, foundIndex);
    } else {
        printf("Element %d not found in the array.\n", target);
    }

    return 0;
}

