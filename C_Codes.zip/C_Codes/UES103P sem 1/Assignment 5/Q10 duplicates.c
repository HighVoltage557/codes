#include <stdio.h>

int main() {
    int originalArray[] = {1, 2, 2, 3, 4, 4, 5, 5, 5};
    int size = sizeof(originalArray) / sizeof(originalArray[0]);

    // Create a new array to store unique elements
    int newArray[size];
    int newSize = 0; // Initialize the size of the new array

    // Check each element in the original array
    for (i = 0; i < size; i++) {
        int isDuplicate = 0; // Flag to track duplicates

        // Compare with elements already added to the new array
        for (j = 0; j < newSize; j++) {
            if (originalArray[i] == newArray[j]) {
                isDuplicate = 1;
                break; // Found a duplicate, no need to continue
            }
        }

        // If not a duplicate, add it to the new array
        if (!isDuplicate) {
            newArray[newSize] = originalArray[i];
            newSize++;
        }
    }

    // Print the new array (without duplicates)
    printf("Array after removing duplicates: ");
    for (i = 0; i < newSize; i++) {
        printf("%d ", newArray[i]);
    }

    return 0;
}

